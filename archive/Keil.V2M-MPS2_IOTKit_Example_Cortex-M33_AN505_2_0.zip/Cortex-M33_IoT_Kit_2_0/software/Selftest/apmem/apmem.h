/*
 * Copyright:
 * ----------------------------------------------------------------
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 *   (C) COPYRIGHT 2014 ARM Limited
 *       ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 * ----------------------------------------------------------------
 * File:     apmem.h
 * Release:  Version 2.0
 * ----------------------------------------------------------------
 */

/*
 *            Memory Interface Support
 *            ========================
 */

#ifndef _APMEM_H_
#define _APMEM_H_

#include "common.h"

// Memory region boundaries
#define DEFAULT_LOAD_ADDRESS    0x00000000                      // Possible load address of this program in memory
#define DEFAULT_STACK_BASE      0x00800000                      // Grows downwards. T.B.A

// Addresses for memory test
#define ZBT1_BASE       0x00100000  // 0x000000 + 0x100000 (selftest.axf)
#define ZBT2_BASE       0x28000000	// 2MB
#define ZBT3_BASE       0x28200000	// 2MB
#define SRAM_BASE       0x20000000  // 32K internal sram
#define PSRAM_BASE      0x80000000  // 16MB 

#define ZBT1_SIZE       0x400000 - ZBT1_BASE    // 4MB
#define ZBT2_SIZE       0x200000    // 2MB
#define ZBT3_SIZE       0x200000    // 2MB
#define SRAM_SIZE       0x8000      // 32K internal sram
#define PSRAM_SIZE      0x1000000   // 16MB

#define ADDRESS_MAX             30                              // Test memory array size
#define LOADSTORES_MAX          8

// Secure Memory Addresses
#define ZBT1_SEC_BASE       0x10100000  // 0x000000 + 0x100000 (selftest.axf)
#define ZBT2_SEC_BASE       0x38000000	// 2MB
#define ZBT3_SEC_BASE       0x38200000	// 2MB
#define SRAM_SEC_BASE       0x30000000  // 32K internal sram



// External function types

/*  Function: apMEM_TEST(void)
 *   Purpose: Main entry for Memory test
 *
 * Arguments: None
 *   Returns:
 *        OK: apERR_NONE
 *     Error: apERR_MEM_START;
 */
apError apMEM_TEST(void);

#endif
