Selftest project
================

The selftest source code and project files are intended for
use with Keil MDK Microcontroller Development Kit version 5.

The included executables were built with MDK version 5.22
with the compiler version set to 6.6



Selftest Loopback Cables
========================

The selftest software needs loopback cables for three of the tests.


Test 1 - AACI
=============

The audio loopback cable is a simple straight-through
audio cable connected between the AIN and AOUT 3.5mm
stereo jack sockets:


Connector A          Connector B
-----------          -----------

   Tip ----------------- Tip
  Ring ----------------- Ring
 Sleeve --------------- Sleeve



Test 5 - SSP (EEPROM)
=====================

This test uses a Microchip 25LC128 serial EEPROM connected to
the SPI socket as follows:



     --------------------------------------------------
    |                            |                     |
  --|-----------------------     |                     |
 |  |                       |    |                     |
 |  |    SPI                |    |     25LC128         |
 |  |   ------              |    |    ----------       |
 |   --|o5  6o|------       |    |   |o         |      |
  -----|o3  4o|------|------|----|--[| 1      8 |]-----|
     --|o1  2o|--    |      |    |   |          |      |
    |   ------   |   |       ----|--[| 2      7 |]-----
    |            |   |           |   |          |
    |            |   |            --[| 3      6 |]-----
    |            |   |               |          |      |
     ------------|---|--------------[| 4      5 |]--   |
                 |   |               |          |   |  |
                 |   |                ----------    |  |
                 |   |                              |  |
                 |    ------------------------------   |
                 |                                     |
                  -------------------------------------




Test 6 - Ethernet
=================

The ethernet loopback cable is a single RJ45 connector
wired as follows:


Pin 1 (orange/white) ------------ Pin 3 (green/white)
Pin 2 (orange) ------------------ Pin 6 (green)
