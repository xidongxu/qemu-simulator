/*
 * Copyright:
 * ----------------------------------------------------------------
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 *   (C) COPYRIGHT 2003,2004 ARM Limited
 *       ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 * ----------------------------------------------------------------
 * File:     apdma.h
 * Release:  Version 3.0.1
 * ----------------------------------------------------------------
 *
 */

#ifndef _APDMA_H_
#define _APDMA_H_

#include "SMM_MPS2.h"

// PL080 DMAC register address offsets
typedef struct
{
  __I  uint32_t DMACIntStatus;                  /* Offset: 0x000 (RO) Interrupt status register */
  __I  uint32_t DMACIntTCStatus;                /* Offset: 0x004 (RO) Interrupt Terminal Count status register */
  __O  uint32_t DMACIntTCClear;                 /* Offset: 0x008 (WO) Interrupt Terminal Count clear register */
  __I  uint32_t DMACIntErrorStatus;             /* Offset: 0x00C (RO) Interrupt Error status register */
  __O  uint32_t DMACIntErrClear;                /* Offset: 0x010 (WO) Interrupt Error clear register */
  __I  uint32_t DMACRawIntTCStatus;             /* Offset: 0x014 (RO) Raw Interrupt Terminal Count status register */
  __I  uint32_t DMACRawIntErrorStatus;          /* Offset: 0x018 (RO) Raw Interrupt Error status register */
  __I  uint32_t DMACEnabldChns;                 /* Offset: 0x01C (RO) Enabled Channel register */
  __IO uint32_t DMACSoftBReq;                   /* Offset: 0x020 (R/W) Software Burst request register */
  __IO uint32_t DMACSoftSReq;                   /* Offset: 0x024 (R/W) Software Single request register */
  __IO uint32_t DMACSoftLBReq;                  /* Offset: 0x028 (R/W) Software Last Burst request register */
  __IO uint32_t DMACSoftLSReq;                  /* Offset: 0x02C (R/W) Software Last Single request register */
  __IO uint32_t DMACConfiguration;              /* Offset: 0x030 (R/W) Configuration register */
  __IO uint32_t DMACSync;                       /* Offset: 0x034 (R/W) Synchronisation register */
       uint32_t Reserved0[50];
  __IO uint32_t DMACC0SrcAddr;                  /* Offset: 0x100 (R/W) Channel Source Address register */
  __IO uint32_t DMACC0DestAddr;                 /* Offset: 0x104 (R/W) Channel Destination Address register */
  __IO uint32_t DMACC0LLI;                      /* Offset: 0x108 (R/W) Channel Linked List Item register */
  __IO uint32_t DMACC0Control;                  /* Offset: 0x10C (R/W) Channel Control register */
  __IO uint32_t DMACC0Configuration;            /* Offset: 0x110 (R/W) Channel Configuration register */
       uint32_t Reserved1[3];
  __IO uint32_t DMACC1SrcAddr;                  /* Offset: 0x120 (R/W) Channel Source Address register */
  __IO uint32_t DMACC1DestAddr;                 /* Offset: 0x124 (R/W) Channel Destination Address register */
  __IO uint32_t DMACC1LLI;                      /* Offset: 0x128 (R/W) Channel Linked List Item register */
  __IO uint32_t DMACC1Control;                  /* Offset: 0x12C (R/W) Channel Control register */
  __IO uint32_t DMACC1Configuration;            /* Offset: 0x130 (R/W) Channel Configuration register */
       uint32_t Reserved2[243];
  __IO uint32_t DMACITCR;                       /* Offset: 0x500 R/W Test Control Register */
  __IO uint32_t DMACITOP1;                      /* Offset: 0x504 R/W Test Output Register 1 */
  __IO uint32_t DMACITOP2;                      /* Offset: 0x504 R/W Test Output Register 2 */
  __IO uint32_t DMACITOP3;                      /* Offset: 0x504 R/W Test Output Register 3 */
       uint32_t Reserved3[694];
  __I  uint32_t DMACPeriphID0;                  /* Offset: 0xFE0 (RO) Perpheral ID Register 0 */
  __I  uint32_t DMACPeriphID1;                  /* Offset: 0xFE4 (RO) Perpheral ID Register 1 */
  __I  uint32_t DMACPeriphID2;                  /* Offset: 0xFE8 (RO) Perpheral ID Register 2 */
  __I  uint32_t DMACPeriphID3;                  /* Offset: 0xFEC (RO) Perpheral ID Register 3 */
  __I  uint32_t DMACPCellID0;                   /* Offset: 0xFF0 (RO) PrimeCell ID Register 0 */
  __I  uint32_t DMACPCellID1;                   /* Offset: 0xFF0 (RO) PrimeCell ID Register 1 */
  __I  uint32_t DMACPCellID2;                   /* Offset: 0xFF0 (RO) PrimeCell ID Register 2 */
  __I  uint32_t DMACPCellID3;                   /* Offset: 0xFF0 (RO) PrimeCell ID Register 3 */
} CMSDK_PL081_TypeDef;
    
    
// DMA Controller Configration Register Bit Assignments
#define AHBM_littleendian  (0 << 1)
#define AHBM_bigendian     (1 << 1)
#define DMAC_enable         (1 << 0)

// DMA Controller Channel 0\1 Control Register
/* The total size of the payload transferred is controlled by this register.
 * The transfer size field represents the number of units to be transferred,
 * and the unit size is determined by the source width field. As a result,
 * total number of bytes transferred equals source width * transfer size.
 * This means that, for a transfer with width w, and transfer size t,
 * the total payload p is w*t bytes. By a single transfer, it is meant a
 * single transfer done by each linked list item.
 */
#define tc_int_enable       (0x80000000)    // Terminal Count interrupt enable bit
#define dest_increment      (1 << 27)       // When set destination address is incremented after each transfer
#define src_increment       (1 << 26)       // When set source address is incremented after each transfer

#define dwidth_shift        21              // Bits [23:21] Destination transfer width
#define swidth_shift        18              // Bits [20:18] Source transfer width

enum transfer_width {
    width_8bit      = 0,
    width_16bit     = 1,
    width_32bit     = 2
};

#define dest_burst          15              // Bits [17:15] Destination burst size
#define source_burst        12              // Bits [14:12] Source burst size

enum burstsize {
    burst_1bytes  = 0,
    burst_4bytes  = 1,
    burst_8bytes  = 2,
    burst_16bytes = 3,
    burst_32bytes = 4,
    burst_64bytes = 5,
    burst_128bytes= 6,
    burst_256bytes = 7
};

#define transfer_size         0             // Bits [11:0] Transfer size


// Channel 0\1 configration Register Bit Assignments
#define halt                (1 << 18)       // Halt
#define active              (1 << 17)       // Active (Read Only)
#define locked              (1 << 16)       // Enables Locked transfers
#define tc_int_mask         (1 << 15)       // Terminal Count Interrupt Mask
#define int_err_mask        (1 << 14)       // Interrupt Error Mask


// bits [13:11] flow control
enum flow_ctrl {
    fctrl_dmac_m_to_m   = 0,    // Memory to memory, DMAC does flow control
    fctrl_dmac_m_to_p   = 1,    // Memory to periph, DMAC does flow control
    fctrl_dmac_p_to_m   = 2,    // Periph to memory, DMAC does flow control
    fctrl_dmac_p_to_p   = 3,    // Periph to periph, DMAC does flow control
    fctrl_dest_p_to_p   = 4,    // Periph to periph, destination does flow control
    fctrl_dest_m_to_p   = 5,    // Memory to periph, destination does flow control
    fctrl_src_p_to_m    = 6,    // Periph to memory, source does flow control
    fctrl_src_p_to_p    = 7     // Periph to periph, source does flow control
};

// Bits [9:6] Destination peripheral
// Bits [4:1] Source peripheral
// These channels distinguish among peripherals, and it applies only when
// transfers are defined to include a peripheral on either side or both sides.
enum periph_channel {           /* To Be defined */
    DMA_CHAN_USER0      = 0,
    DMA_CHAN_USER1      = 1,
    DMA_CHAN_USER2      = 2,
    DMA_CHAN_MMCI       = 3,
    DMA_CHAN_AACIRx     = 4,
    DMA_CHAN_AACITx     = 5,
    DMA_CHAN_SCI0Rx     = 6,
    DMA_CHAN_SCI0Tx     = 7,
    DMA_CHAN_SSP0Rx     = 8,
    DMA_CHAN_SSP0Tx     = 9,
    DMA_CHAN_UART2Rx    = 10,
    DMA_CHAN_UART2Tx    = 11,
    DMA_CHAN_UART1Rx    = 12,
    DMA_CHAN_UART1Tx    = 13,
    DMA_CHAN_UART3Rx    = 14,
    DMA_CHAN_UART3Tx    = 15
};


#define channel_enable      (1 << 0)



// Represents a single transfer item.
typedef struct linked_list_item {
    unsigned int src;
    unsigned int dest;
    unsigned int next;
    unsigned int control;

} lli_t;

// Defines the *total* payload to be transferred in bytes
#define DMA_PAYLOAD_SIZE    1024 * 8
extern unsigned int *payload;

extern const unsigned int dma_blocksize;

void setup_dma( unsigned int src_addr, unsigned int dest_addr,
                unsigned int chan_control, unsigned int chan_config, unsigned int dma_config,
                enum transfer_width swidth, enum transfer_width dwidth);
void enable_DMAC(void);

int check_transfer_complete(void);

int dma_test(void);
int dma_test_0(void);
int dma_test_1(void);
int dma_test_2(void);
int dma_test_3(void);
int secure_dma_test_0(void);
int secure_dma_test_1(void);
int secure_dma_test_2(void);
int secure_dma_test_3(void);

#endif /*_APDMA_H_ */

