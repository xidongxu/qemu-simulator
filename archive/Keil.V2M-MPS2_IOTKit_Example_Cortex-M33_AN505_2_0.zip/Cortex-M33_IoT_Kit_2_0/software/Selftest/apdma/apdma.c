/*
 * Copyright:
 * ----------------------------------------------------------------
 * This confidential and proprietary software may be used only as
 * authorised by a licensing agreement from ARM Limited
 *   (C) COPYRIGHT 2003,2004 ARM Limited
 *       ALL RIGHTS RESERVED
 * The entire notice above must be reproduced on all authorised
 * copies and copies may only be made to the extent permitted
 * by a licensing agreement from ARM Limited.
 * ----------------------------------------------------------------
 * File:     apdma.c
 * Release:  Version 3.0.2
 * ----------------------------------------------------------------
 *
 *
 */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "apdma.h"

CMSDK_PL081_TypeDef * DMAC_Controller;

unsigned int * payload;
unsigned int * payload_dest;
unsigned int * payload_allocated;
unsigned int * payload_dest_allocated;

// The number of transfer units per LLI.
// Total size is found by dma_blocksize * transfer width
// E.g. for a 32bit transfer width, each unit is a word
// Therefore dma_blocksize * 4 bytes = total number of bytes per lli
// The block size per lli can be a maximum of 2^12 - 1 = 4095.
const unsigned int dma_blocksize = 1024*2;   

// Linked list tables in RAM
lli_t *lli_table;

// Initialises the globally defined payload and its transfer destination
void init_payload(void)
{
    int i;
    unsigned int p_addr, pd_addr;
    unsigned int total_words;

    total_words = DMA_PAYLOAD_SIZE / 4;
    payload = (unsigned int *) malloc(DMA_PAYLOAD_SIZE + 16);       // Allocate 1 MB for src + alignment
    payload_dest = (unsigned int *) malloc(DMA_PAYLOAD_SIZE + 16);  // Allocate 1MB for dest + alignment
    payload_allocated = payload;
    payload_dest_allocated = payload_dest;
    printf("Returned 0x%x for payload, 0x%x for payload_dest\n", 
               (unsigned int)payload, (unsigned int)payload_dest);

    if(!payload || !payload_dest) {
        printf("Error: Insufficient heap for dma test.");

        exit(0);
    }

    p_addr = (unsigned int)payload;
    pd_addr = (unsigned int)payload_dest;

    // Align source and destination to 16 bytes.
    p_addr = p_addr + 16;
    p_addr &= 0xFFFFFFF0;

    pd_addr = pd_addr + 16;
    pd_addr &= 0xFFFFFFF0;

    payload = (unsigned int *)p_addr;
    payload_dest = (unsigned int *)pd_addr;

    printf("Aligned to 0x%x for payload, 0x%x for payload_dest\n", 
               (unsigned int)payload, (unsigned int)payload_dest);

    for(i = 0; i < total_words; i++) {
        switch(i % 4) {
            case 0:
                payload[i] = 0x12345678;
                break;
            case 1:
                payload[i] = 0xAAAAAAAA;
                break;
            case 2:
                payload[i] = 0x23456789;
                break;
            case 3:
                payload[i] = 0xABCDABCD;    
                break;
            default:
                printf("Unknown modulus.\n");
        }
    }
    
    memset((void *)payload_dest, 0, DMA_PAYLOAD_SIZE);
    return;
}
// Sets up linked list registers for transferring blocks
void setup_lli(unsigned int src_addr, unsigned int dest_addr,
                    unsigned int chan_control, enum transfer_width src_width, 
                    enum transfer_width dest_width)
{
    int i;
    unsigned int lli_total;

    // Warning: DMA_PAYLOAD_SIZE *must* be a multiple of (dma_blocksize * (1 << src_width)), 
    // and it must not be less than dma_blocksize. Otherwise LLI's would transfer excess data.
    // This is because each lli transfers dma_blocksize *(1 << src_width) of data and intended
    // data cannot be less than that minimum.

    lli_total = DMA_PAYLOAD_SIZE / (dma_blocksize * (1 << src_width));
    printf("DMA Source starts @ 0x%x. DMA Dest starts @ 0x%x\n", src_addr, dest_addr);
    printf("Total number of llis: %d\n", lli_total);
    lli_table = (lli_t *)malloc(lli_total);
    printf("LLI tables @ 0x%x\n", (unsigned int)lli_table);

    for(i = 0; i < lli_total; i++) {
        lli_table[i].src    = (unsigned int) src_addr + i * dma_blocksize * (1<<src_width);
        lli_table[i].dest   = (unsigned int) dest_addr + i * dma_blocksize * (1 << dest_width);
        lli_table[i].next   = (unsigned int) &lli_table[i+1];
        lli_table[i].control= chan_control;
    }
    lli_table[lli_total-1].next = 0;
}

// Sets up all necessary registers for memory to memory DMA
void setup_dma( unsigned int src_addr, unsigned int dest_addr,
                unsigned int chan_control, unsigned int chan_config, unsigned int dma_config,
                enum transfer_width swidth, enum transfer_width dwidth)
{
    setup_lli(src_addr, dest_addr,chan_control, swidth, dwidth);

    DMAC_Controller->DMACC0LLI = (unsigned int) lli_table[0].next;
    DMAC_Controller->DMACC0SrcAddr = src_addr;
    DMAC_Controller->DMACC0DestAddr = dest_addr;
	DMAC_Controller->DMACC0Control = lli_table[0].control;
	DMAC_Controller->DMACC0Configuration = chan_config;
	DMAC_Controller->DMACConfiguration = dma_config;

    return;
}

// Enables the DMAC and CC0. After this point a transfer must occur.
__inline void enable_DMAC(void)
{
	DMAC_Controller->DMACConfiguration = (DMAC_Controller->DMACConfiguration | 1);      // Enable DMAC
	DMAC_Controller->DMACC0Configuration = (DMAC_Controller->DMACC0Configuration | 1);  // Enable DMAC Channel 0
}

void disable_DMAC(void)
{
    DMAC_Controller->DMACC0Configuration = 0;
    DMAC_Controller->DMACConfiguration = 0;
}

// Compares memory locations to test whether DMA was successful.
int check_transfer_complete(void)
{
    int i;
    int error = 0;
    unsigned int total_words;

    total_words = DMA_PAYLOAD_SIZE / 4;

    for(i = 0; i < total_words; i++) {
        if(payload[i] != payload_dest[i]) {
            printf("Error: payload[%d]: %#08x, payload_dest[%d]: %#08x\n",
                    i, payload[i], i, payload_dest[i]);
            error = 1;
            break;
        }
    }
    return error;
}

// Initiates memory to memory dma
int memory_to_memory(unsigned int src, unsigned int dest)
{
    unsigned int DMACC0Control_word, DMACC0Config_word, DMACConfig_word;
    volatile int total_words;
    int error = 0;

    disable_DMAC();

    DMACC0Control_word  = src_increment | dest_increment | tc_int_enable | 
                        (width_32bit << dwidth_shift) | (width_32bit << swidth_shift)  |
                        (burst_256bytes << dest_burst) | (burst_256bytes << source_burst) |
                        dma_blocksize;

    DMACC0Config_word   = tc_int_mask | int_err_mask | fctrl_dmac_m_to_m;
                          
    DMACConfig_word     = 0;	// Little-endian, controller disabled; no bits need setting here.

    setup_dma(src, dest, DMACC0Control_word, DMACC0Config_word,
                DMACConfig_word, width_32bit, width_32bit);

    DMAC_Controller->DMACIntTCClear = 0xFFFFFFFF;

    total_words = DMA_PAYLOAD_SIZE / 4;

    enable_DMAC();

    // Poll the irq registers
    while(!DMAC_Controller->DMACRawIntTCStatus && !DMAC_Controller->DMACIntStatus) {
        ;
    }

    if(DMAC_Controller->DMACIntErrorStatus & 1)
    {
        printf("Error: DMA interrupt on error.\n");
    }
    
    if(check_transfer_complete()) {
        printf("Error: DMA transfers unsuccessful or incomplete.\n");
        error = 1;
    }

    free((void *)payload_allocated);
    free((void *)payload_dest_allocated);
    free((void *)lli_table);
    return error;
}


// Tests memory/memory dma transfers
int dma_test(void)
{
	  int pass = 1;

    printf("Non-Secure DMA0 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA0_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Non-Secure DMA1 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA1_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Non-Secure DMA2 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA2_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Non-Secure DMA3 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA3_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Secure DMA0 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA0_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Secure DMA1 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA1_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Secure DMA2 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA2_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
    printf("Secure DMA3 Test.\n");	
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA3_BASE;
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n\n");
			  pass = 0;
    }
    else {
        printf("Memory blocks transferred successfully by DMA.\n\n");
    }
		
    if(pass == 0) {
        printf("Test failure.\n");
			  return 1;
    }
    else {
        printf("Tests passed.\n");
    }
    return 0;
}

int dma_test_0(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA0_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int dma_test_1(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA1_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int dma_test_2(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA2_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int dma_test_3(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)CMSDK_DMA3_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int secure_dma_test_0(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA0_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int secure_dma_test_1(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA1_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int secure_dma_test_2(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA2_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}

int secure_dma_test_3(void)
{
    DMAC_Controller = (CMSDK_PL081_TypeDef*)SEC_DMA3_BASE;
    
    init_payload();
    if(memory_to_memory((unsigned int) payload, (unsigned int) payload_dest )) {
        printf("Error: Memory to memory DMA transfers failed.\n");
        return 1;
    }

    printf("Memory blocks transferred successfully by DMA.\n");
    return 0;
}
