Cortex-M33 IoT Kit for V2M-MPS2+ version 2.0
--------------------------------------------

This is version 2.0 of the Cortex-M33 IoT Kit
for use on a Cortex-M Prototyping System Board
type V2M-MPS2+

Please read the End User Licence Agreement in the file
Licence.pdf and ensure that you agree with the terms
it contains before using the IoT kit.


Loading the Cortex-M33 image onto the V2M-MPS2+ board
-----------------------------------------------------

The most straightforward way to configure the V2M-MPS2+
board with the Cortex-M33 IoT kit design is to entirely
replace the contents of the board's configuration memory
with the files provided in the Recovery directory in this
file package.  Proceed as follows:

1) Connect the USB configuration port of the V2M-MPS2+
   board to your host computer.

2) Connect 12 volt power to the V2M-MPS2+ board.
   (The configuration memory will appear on the host
    computer as a USB mass storage device).

3) Save any existing files in the configuration memory
   that you wish to retain for future use, in a location
   elsewhere from the configuration memory.

4) Format the configuration memory, preferably FAT 16
   although FAT 32 can also be used.

5) Copy the files from the Recovery directory of this
   package to the configuration memory, preserving the
   directory structure.  The directory level which
   contains the file "config.txt" should be in the
   root of the configuration memory.

6) Press the button labelled "ON" to power up and
   configure the V2M-MPS2+ board.


Keil uVision MDK5 software pack
-------------------------------

The software pack which contains support for the
Cortex-M33 Iot Kit is:

Keil.V2M-MPS2_IOTKit_BSP.1.0.0.pack (or later)

obtainable from:

http://www.keil.com/dd2/pack/

(ARM V2M-MPS2 Device Family Pack for IOT-Kit devices)
