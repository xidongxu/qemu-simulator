The Rowley ARM7 demo uses the GCC ARM7 port files.
